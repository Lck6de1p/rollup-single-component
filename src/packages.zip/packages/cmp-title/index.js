import Vue from 'vue';
import cmpTitle from './index.vue';

Vue.component('cmp-title', cmpTitle);