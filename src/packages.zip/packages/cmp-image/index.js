import Vue from 'vue';
import cmpImage from './index.vue';

Vue.component('cmp-image', cmpImage);