<template>
  <div :style="styleObject" class="imgs-wrapper">
    <img
      v-for="(img, index) in imgs"
      :src="img.imgUrl"
      :key="index"
      :class="{ 'has-radius': hasRadius === '1' }"
    />
  </div>
</template>

<script>
export default {
  name: "cmp-image",
  props: {
    imgs: {
      type: Array,
      default: () => ["http://www.lck6de1p.com/static/1.jpg"],
    },
    backgroundColor: {
      type: String,
      default: "#fff",
    },
    borderStyle: {
      type: String,
      default: "1",
    },
    hasRadius: {
      type: String,
      default: "1",
    },
    // 上下padding
    TBBorder: {
      type: [Number, String],
      default: "15",
    },
    // 左右padding
    LRBorder: {
      type: [Number, String],
      default: "15",
    },
    imgBorder: {
      type: [Number, String],
      default: "15",
    },
  },
  computed: {
    styleObject() {
      let style = {};
      if (this.borderStyle === "2") {
        style["padding"] = `${this.TBBorder}px ${this.LRBorder}px`;
        style["--imgBorder"] = `${this.imgBorder}px`;
      } else {
        style["padding"] = "15px 15px 0 15px";
        style["--imgBorder"] = `12px`;
      }
      style["backgroundColor"] = `${this.backgroundColor}`;
      return style;
    },
  },
};
</script>

<style lang="less">
.imgs-wrapper {
  img {
    width: 100%;
    margin-bottom: 15px;
    &:not(:last-child) {
      margin-bottom: var(--imgBorder);
    }
  }
  .has-radius {
    border-radius: 15px;
  }
}
</style>
